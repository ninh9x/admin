<?php
/* ------ MAIN SETTINGS ------ */
/* Website URL (Without www!)(Do Not End With '/') */
$site_url = 'http://vvvvvvvv';
/* Website title */
$site_title = 'MovieStore';
/* iTunes Store 2-Letter Country Code (http://moviestore.armorthemes.com/countries) */
$site_country = 'us';
/* iTunes Affiliate Token (Optional) */
$itunes_id = '';
/* Amazon Associates Tracking ID (Optional) */
$amazon_id = '';
/* Amazon Store Country (Optional) */
$amazon_country = 'amazon.com';
/* themoviedb.org API Key (Optional) For ratings and photo background */
$apikey = '';
/* Youtube API Key (Optional) For trailers */
$youtube_key = '';
/* AddThis ID for sharing analytics (Optional) */
$addthis_id = '';
/* Disqus shortname for comments (Optional) */
$disqus_shortname = '';
/* Contact form mail receiver (Optional) */
$contact_email = '';
/* ------ SEO SETTINGS ------ */
/* Homepage title */
$homepage_title = 'MovieStore - Movies and TV Shows Affiliate Script';
/* Homepage meta description */
$homepage_desc = 'Welcome to the best Movies and TV Shows Affiliate Script.';
/* Website meta keywords */
$site_keywords = 'MovieStore, movies, tv shows, itunes affiliate script, php movies script, php movies affiliate script, movie script';
/* Movie single page title (Comes between movie title and site title) */
$movie_page_title = 'Movie';
/* TV Shows single page title (Comes between tv show title and site title) */
$tv_page_title = 'TV Show';
/* ------ HOMEPAGE CAROUSEL GENRE (Get id from the genre url) (Leave blank for all genres) ------ */
$home_genre_id = '';
/* ------ HOMEPAGE FEATURED MOVIES (Get id from the movie url) ------ */
$feat_id1 = '1159762255';
$feat_id2 = '1133650155';
$feat_id3 = '1134823596';
$feat_id4 = '1139413055';
/* ------ TRANSLATION OPTIONS ------ */
/* Homepage */
$home_carousel_title = 'Popular Movies';
$featapps_title = 'Featured Movies';
$hometv_title = 'Popular TV Shows';
$rmore_title = 'Read More';
/* Single Movie, Season, Episode Page */
$byartist_mpage = 'By';
$cat_mpage = 'Genre';
$release_mpage = 'Release Date';
$adrat_mpage = 'Advisory Rating';
$time_mpage = 'Runtime';
$dir_mpage = 'Director';
$act_mpage = 'Production Company';
$awards_mpage = 'Production Country';
$buytext_mpage = 'iTunes Price';
$buyhdtext_mpage = 'iTunes HD Price';
$renttext_mpage = 'iTunes Rent Price';
$itunelink_mpage = 'Buy on iTunes';
$amazonlink_mpage = 'Buy on Amazon';
$from_mpage = 'From';
$ratings_mpage = 'Ratings';
$epis_mpage = 'Episodes';
$eptit_mpage = 'Title';
$eptim_mpage = 'Time';
$eppri_mpage = 'Price';
$seaso_mpage = 'Season Only';
$descriphead_mpage = 'Description';
$trail_mpage = 'Trailer';
$photo_mpage = 'Photos';
$reviewshead_mpage = 'Reviews';
$reviewsby_mpage = 'By';
$commentbox_mpage = 'Comments';
$moremovies_mpage = 'Movies by';
$moretvshow_mpage = 'Seasons';
/* Header and Navigation Pages */
$home_title = 'Home';
$movies_navtitle = 'Movies';
$topmovies_title = 'Top Movies';
$toprental_title = 'Top Movie Rentals';
$tvseries_navtitle = 'TV Shows';
$toptvseasons_title = 'Top TV Seasons';
$toptvepisodes_title = 'Top TV Episodes';
$nr_episodes = 'Episodes';
$filter_title = 'Filter by Genre';
/* Search Form */
$searchf_text = 'Search for...';
$searchf_movies = 'Movies';
$searchf_tv = 'TV Shows';
/* Search Page */
$searchresults_title = 'Search Results For';
$search_noresults_title = 'Sorry, no results were found.';
/* Movie Genres Titles */
$gtitle_all = 'All Genres';
$gtitle_1 = 'Action Adventure';
$gtitle_2 = 'Anime';
$gtitle_3 = 'Classics';
$gtitle_4 = 'Comedy';
$gtitle_5 = 'Documentary';
$gtitle_6 = 'Drama';
$gtitle_7 = 'Foreign';
$gtitle_8 = 'Horror';
$gtitle_9 = 'Independent';
$gtitle_10 = 'Kids Family';
$gtitle_11 = 'Musicals';
$gtitle_12 = 'Romance';
$gtitle_13 = 'Sci-Fi Fantasy';
$gtitle_14 = 'Short Films';
$gtitle_15 = 'Special Interest';
$gtitle_16 = 'Thriller';
$gtitle_17 = 'Sports';
$gtitle_18 = 'Western';
/* TV Shows Genres Titles */
$tvgtitle_all = 'All Genres';
$tvgtitle_1 = 'Action Adventure';
$tvgtitle_2 = 'Animation';
$tvgtitle_3 = 'Classic';
$tvgtitle_4 = 'Comedy';
$tvgtitle_5 = 'Drama';
$tvgtitle_6 = 'Kids';
$tvgtitle_7 = 'Nonfiction';
$tvgtitle_8 = 'Reality TV';
$tvgtitle_9 = 'Sci-Fi Fantasy';
$tvgtitle_10 = 'Sports';
$tvgtitle_11 = 'Teens';
/* Footer Links */
$footnav_home = 'Home';
$footnav_privacy = 'Privacy Policy';
$footnav_dmca = 'DMCA';
$footnav_contact = 'Contact';
?>