<?php 
require_once('siteconfig.php');
require_once('url_slug.php');
require_once('includes/tmdb-api.php');
$link_id = $_GET['id'];
$data = file_get_contents('https://itunes.apple.com/lookup?id='.$link_id.'&entity=tvEpisode&country='.$site_country.'');
$response = json_decode($data);
// fallback default country
if ($response->resultCount == '0') {
$data = file_get_contents('https://itunes.apple.com/lookup?id='.$link_id.'&entity=tvEpisode');
$response = json_decode($data);
}
// echo '<pre>'; print_r( $response ); echo '</pre>';
$item_title = $response->results[0]->collectionName;
// strip (year) from movie title
// $item_title = preg_replace('@\(.*?\)@', '', $item_title);
// itunes api edits
$artist_id = $response->results[0]->artistId;
$artist_title = $response->results[0]->artistName;
$genre_title = $response->results[0]->primaryGenreName;
$seo_desc = substr($response->results[0]->longDescription, 0, 180);
$sslimage = preg_replace('/http/ms', "http", $response->results[0]->artworkUrl100);
$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
$main_image = preg_replace('/100x100bb.jpg/ms', "200x200bb.jpg", $sslimage);
$geo_link = preg_replace('/itunes/ms', "geo.itunes", $response->results[0]->collectionViewUrl);
// tmdb api
// movie title
$q = $artist_title;
$page = '1';
$language = 'en';
// connect to tmdb
$tmdb = new TMDB($apikey, $language, true);
// search movie
$result = $tmdb->searchTVShow($q,$page);
if (isset($result['results'][0]['id']) and !empty($result['results'][0]['id'])) {
$tv_id = $result['results'][0]['id'];
$row = $tmdb->getTVShow($tv_id);
// build thumb url
$thumbpath = "https://image.tmdb.org/t/p/w185";
// build image url 
$imagepath = "https://image.tmdb.org/t/p/original";
// build cast thumb url
$castthumbpath = "https://image.tmdb.org/t/p/w45";
//EXTRA build image url 
$backpath = "https://image.tmdb.org/t/p/w780";
}
// time format
function formatMilliseconds($milliseconds) {
    $seconds = floor($milliseconds / 1000);
    $minutes = floor($seconds / 60);
    $hours = floor($minutes / 60);
    $milliseconds = $milliseconds % 1000;
    $seconds = $seconds % 60;
    $minutes = $minutes % 60;

    //$format = '%2u:%02u';
    //$time = sprintf($format, $minutes, $seconds);
	if ($hours == '0') {
	$format = '%02u:%02u';
    $time = sprintf($format, $minutes, $seconds);
	}
	else {
	$format = '%2u:%02u:%02u';
    $time = sprintf($format, $hours, $minutes, $seconds);
	}
	return $time;
}
?>
<!doctype html>
<html>
    <head>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width">
		<title><?php echo $item_title;?> - <?php echo $tv_page_title;?> - <?php echo $site_title;?></title>
		<meta name="description" content="<?php echo $seo_desc;?>" />
		<meta name="keywords" content="<?php echo $item_title;?>, <?php echo $site_keywords;?>" />
		<meta property="og:site_name" content="<?php echo $site_title; ?>"/>
		<meta property="og:type" content="article"/>
		<meta property="og:title" content="<?php echo $item_title;?> - <?php echo $tv_page_title;?> - <?php echo $site_title;?>"/>
		<meta property="og:description" content="<?php echo $seo_desc;?>"/>
		<meta property="og:image" content="<?php echo $main_image;?>">
		<!-- CSS and Scripts -->
		<?php include 'includes/headscripts.php'; ?>
		<?php include 'ads/head_code.php'; ?>
	  
    </head>
<body>
<?php include 'includes/header.php'; ?>
<div class="headpage" style="background-image:url(<?php
                            if (!isset($row['backdrop_path']) or empty($row['backdrop_path'])):
                                echo $site_url .'/images/noback.jpg';
                            else:
                                echo '' . $backpath . $row['backdrop_path'] . '';
                            endif;
                            ?>);">
<div class="headpageoverlay">
<div class="container">
		<div class="headpageimage">
		<img data-src="<?php echo $main_image?>" src="<?php echo $site_url?>/images/loading.svg" alt="<?php echo $item_title;?>" height="200px" width="200px">
		</div>
		<div class="headpageinfo">
		<h1 class="product-title"><?php echo $item_title;?></h1>
		<h2 class="product-stock"><?php echo $artist_title;?></h2>
		<ul style="list-style:none;padding: 0px;">
		<li><b><?php echo $cat_mpage;?>:</b> <?php echo $response->results[0]->primaryGenreName;?></li>
		<li><b><?php echo $release_mpage;?>:</b> <?php echo substr($response->results[0]->releaseDate,0,10);?></li>
		<?php if(isset($response->results[0]->contentAdvisoryRating) and !empty($response->results[0]->contentAdvisoryRating)): ?>
		<li><b><?php echo $adrat_mpage;?>:</b> <?php echo $response->results[0]->contentAdvisoryRating;?></li>
		<?php endif; ?>
		<?php if(isset($response->results[0]->trackCount) and !empty($response->results[0]->trackCount)): ?>
		<li><b><?php echo $epis_mpage;?>:</b> <?php echo $response->results[0]->trackCount;?></li>
		<?php endif; ?>
		<?php if(isset($response->results[0]->collectionPrice) and !empty($response->results[0]->collectionPrice)): ?>
		<li><b><?php echo $buytext_mpage;?>:</b> <?php echo $response->results[0]->currency;?> <?php echo $response->results[0]->collectionPrice;?>
		<?php endif; ?>
		<?php if(isset($response->results[0]->collectionHdPrice) and !empty($response->results[0]->collectionHdPrice)): ?>
		<li><b><?php echo $buyhdtext_mpage;?>:</b> <?php echo $response->results[0]->currency;?> <?php echo $response->results[0]->collectionHdPrice;?>
		<?php endif; ?>
		</ul>
		</div>
		<div class="headpageright">
	    <?php if(isset($row['vote_average']) and !empty($row['vote_average'])): ?>
		<div class="product-rating">
		<div class="score"><span><?php echo $row['vote_average'];?></span><span class="muted">/10</span></div>
		<div class="bigstarbox">
        <span class="bigstars"><?php echo $row['vote_average'];?></span>
		</div>
		<div class="scorecount"><span><?php echo $from_mpage;?> <?php echo number_format($row['vote_count']);?> <?php echo $ratings_mpage;?></span></div>
		</div>
		<?php endif; ?>
		<div class="postactions">
<a href="<?php echo $geo_link; ?>&at=<?php echo $itunes_id;?>" target="_blank" class="btn btn-raised btn-warning" rel="nofollow"><?php echo $itunelink_mpage;?></a>
<?php if(isset($amazon_id) and !empty($amazon_id)): ?>
<a href="https://www.<?php echo $amazon_country;?>/gp/search?ie=UTF8&camp=1789&creative=9325&index=movies-tv&keywords=<?php echo $item_title;?>&linkCode=ur2&tag=<?php echo $amazon_id;?>" target="_blank" class="btn btn-raised btn-danger"><?php echo $amazonlink_mpage;?></a>
<?php endif; ?>
<div class="sharebox">
<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_compact"></a>
</div>
</div>
</div>
        </div>
</div>
</div>
</div>
<div class="container">
<div class="col-md-8" style="margin-top: 30px;padding-left:0px;">
<div class="postmain">
<div class="postmaintitle" style="margin-bottom:0px;">
<h3><?php echo $descriphead_mpage;?></h3>
</div>
<div class="postmaindescr">
<p>
<?php echo $response->results[0]->longDescription;?>
</p>
</div>
</div>
<!-- end .postmain -->

<div class="postmain">
<div class="postmaintitle" style="margin-bottom:5px;">
<h3><?php echo $epis_mpage;?></h3>
</div>
<div class="table-responsive">
<table class="table table-hover">
    <thead>
      <tr>
		<th></th>
        <th><?php echo $eptit_mpage;?></th>
        <th><?php echo $eptim_mpage;?></th>
        <th><?php echo $eppri_mpage;?></th>
		<th></th>
      </tr>
    </thead>
    <tbody>  
<?php 
$counter = 0;
foreach ($response->results as $a) {
        if ($a->wrapperType == 'track') { 
?>
<tr>
	<td><?php echo $counter; ?></td>
	<td><?php echo substr($a->trackName,0,40); ?></td>
	<td><?php echo formatMilliseconds($a->trackTimeMillis); ?></td>
	<td><?php
	if ($a->trackPrice == '0') {
	echo "Free"; 
	}
	elseif ($a->trackPrice == '-1') {
	echo $seaso_mpage; 
	}
	else {
	echo $a->currency.' '.$a->trackPrice; 
	}
?></td>
<td>
<a style="margin: 0px 0px;float: right;text-transform: none;" class="btn btn-raised btn-warning btn-sm" href="<?php echo preg_replace('/itunes/ms', "geo.itunes", $a->trackViewUrl); ?>&at=<?php echo $itunes_id;?>" target="_blank" rel="nofollow"><?php echo $itunelink_mpage;?></a>
</td>
</tr>
<?php
}  
$counter++;		
    }
?>
</tbody>
</table> 
</div>
</div>
<!-- end .postmain -->

<?php 
$postad = file_get_contents("ads/singlepage_ad_728x90.php",NULL);
if(isset($postad) and !empty($postad)): ?>
<div style="margin:0px 0px 20px 0px;">
<?php echo $postad; ?>
</div>
<?php endif; ?>

<?php if (isset($youtube_key) and !empty($youtube_key)): ?>
<div class="postmain">
<div class="postmaintitle">
<h3><?php echo $trail_mpage;?></h3>
</div>
<!-- 16:9 aspect ratio -->
<div class="embed-responsive embed-responsive-16by9">
<?php
$jsonfile5 = file_get_contents('https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&type=video&q='.urlencode($item_title).'&key='.$youtube_key.'');
$data5 = json_decode($jsonfile5);
$video_kode = $data5->items[0]->id->videoId;
?>
<iframe src="https://www.youtube.com/embed/<?php echo $video_kode;?>?rel=0&modestbranding=1&showinfo=0" frameborder="0" allowfullscreen width="570" height="315" ></iframe>	
</div>
</div>
<!-- end .postmain -->
<?php endif; ?>

<?php 
$jsonurl = "https://itunes.apple.com/$site_country/rss/customerreviews/page=1/id=$link_id/sortBy=mostRecent/json";
$json = file_get_contents($jsonurl,0,null,null);
$json_output = json_decode($json);

$counter = 0;
$max = 21;
if (!empty($json_output->feed->entry)) {
echo '<div class="postmain">
<div class="postmaintitle">
<h3>'.$reviewshead_mpage.'</h3>
</div>

<div id="reviews">
<ul style="list-style:none;padding: 0px;">';
foreach ( $json_output->feed->entry as $entry )
{
if ($counter++ == 0) continue;
	if ($counter < $max) {
	echo "<li>";
	echo "<h4 class=\"tit\">{$entry->title->label}</h4>\n";
	echo '<div class="starbox"><span class="stars">'.$entry->{'im:rating'}->label.'</span></div>';
	echo "<div class=\"auth\">{$reviewsby_mpage} {$entry->author->name->label}</div>\n";
	echo "<div class=\"cont\">{$entry->content->label}</div>\n";
	echo "</li>\n";
	}
    $counter++;	
}
echo '</ul>
</div>
</div>
<!-- end .postmain -->';
}
else {}
?>


<?php if(isset($disqus_shortname) and !empty($disqus_shortname)): ?>
<div class="postmain">
<div class="postmaintitle">
<h3><?php echo $commentbox_mpage;?></h3>
</div>
<div class="videocomments">
<div id="disqus_thread"></div>
<script type="text/javascript">
    /* * * CONFIGURATION VARIABLES * * */
    var disqus_shortname = '<?php echo $disqus_shortname;?>';
    
    /* * * DON'T EDIT BELOW THIS LINE * * */
    (function() {
        var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
        dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
        (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
</div>
</div>
<?php endif; ?>

<!-- end .postmain -->
</div>
<!-- .post-sidebar -->
<div class="col-md-4" style="padding-right:0px;">
<div class="post-sidebar tv">
<div class="post-sidebar-box">
<?php 
$sidead = file_get_contents("ads/sidebar_ad_336x280.php",NULL);
if(isset($sidead) and !empty($sidead)): ?>
<div style="margin:0px 0px 20px 0px;">
<?php echo $sidead; ?>
</div>
<?php endif; ?>
<h3><?php echo $artist_title;?> <?php echo $moretvshow_mpage;?></h3>
<ul class="side-itemlist">
<?php
$data_al = file_get_contents('https://itunes.apple.com/lookup?id='.$artist_id.'&entity=tvSeason');
$response_al = json_decode($data_al);
// echo '<pre>'; print_r( $response_al ); echo '</pre>';
if (isset($response_al->results) and $response_al->results == true){
foreach ($response_al->results as $result_al)
{
	if ($result_al->wrapperType == 'collection') {
	// ssl images
	$sslimage = preg_replace('/http/ms', "http", $result_al->artworkUrl100);
	$relimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	echo '<li class="side-item"><div class="side-thumb"><a href="'.$site_url.'/tv/'.$result_al->collectionId.'/'.cano($result_al->collectionName).'"><img data-src="'.$relimage.'" src="'.$site_url.'/images/loading.svg" ></a></div>
	<div class="info"><h3><a href="'.$site_url.'/tv/'.$result_al->collectionId.'/'.cano($result_al->collectionName).'">'.$result_al->collectionName.'</a></h3>
		<h4>'.$result_al->trackCount.' '.$epis_mpage.'</h4>
		</div>
	</li>';
	}
}
}
?>
</ul>

</div>

</div>
</div>
<!-- end .post-sidebar -->
</div>
<script language="JavaScript" type="text/javascript" src="<?php echo $site_url;?>/js/bigstar-rating.js"></script>
<script type="text/javascript" language="JavaScript">
jQuery(function() {
           jQuery('span.bigstars').bigstars();
      });
</script>
<script language="JavaScript" type="text/javascript" src="<?php echo $site_url;?>/js/star-rating.js"></script>
<script type="text/javascript" language="JavaScript">
      jQuery(function() {
           jQuery('span.stars').stars();
      });
</script>
<script src="<?php echo $site_url;?>/js/imglazyload.js"></script>
<script>
			//lazy loading
			$('.container img').imgLazyLoad({
				// jquery selector or JS object
				container: window,
				// jQuery animations: fadeIn, show, slideDown
				effect: 'fadeIn',
				// animation speed
				speed: 600,
				// animation delay
				delay: 400,
				// callback function
				callback: function(){}
			});
</script>
<script>
$(document).ready(function(){

	// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 200) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});

});
</script>
<p id="back-top"><a href="#top"><i class="material-icons">keyboard_arrow_up</i></a></p>
<?php include "includes/footer.php"; ?>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=<?php echo $addthis_id;?>"></script>
</body>
</html>