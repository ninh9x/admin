<?php
function canogenre($g){
	$g = str_replace(" ", "-", $g);
	$g = strtolower($g);
	return $g;
}
?>
<div class="navbar navbar-default" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<div class="navbar-brand">
			<a href="<?php echo $site_url;?>"><img src="<?php echo $site_url;?>/images/logo.png" alt="<? echo $site_title; ?>" border="0"></a>
			</div>
		</div>
		<div class="navbar-collapse collapse navbar-responsive-collapse">
		<ul class="nav navbar-nav">
		<li><a href="<?php echo $site_url;?>"><?php echo $home_title;?></a></li>
		<li class="dropdown">
		<a href="#" data-target="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $movies_navtitle;?> <b class="caret"></b></a>
		<ul class="dropdown-menu" style="min-width: 160px;">
			<div class="drop-row">
			<li><a href="<?php echo $site_url;?>/top-movies"><?php echo $topmovies_title;?></a></li>	
			<li><a href="<?php echo $site_url;?>/top-movie-rentals"><?php echo $toprental_title;?></a></li>	
			</div>
		</ul>
        </li>
		
		<li class="dropdown">
		<a href="#" data-target="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $tvseries_navtitle;?> <b class="caret"></b></a>
		<ul class="dropdown-menu" style="min-width: 160px;">
			<div class="drop-row">
			<li><a href="<?php echo $site_url;?>/top-tv-seasons"><?php echo $toptvseasons_title;?></a></li>		
			<li><a href="<?php echo $site_url;?>/top-tv-episodes"><?php echo $toptvepisodes_title;?></a></li>	
			</div>
		</ul>
        </li>		
		
		</ul>
<form action="<?php echo $site_url;?>/search_main.php" class="navbar-form navbar-right">

    <input type="text" placeholder="<?php echo $searchf_text; ?>" name="q" class="form-control input-sm" value=""  />
	<input type="hidden" name="change" value="1">
	<select name="entity" class="form-control input-sm">
      <option value="movies"><?php echo $searchf_movies; ?></option>
	  <option value="tvseries"><?php echo $searchf_tv; ?></option>
    </select>
    <button type="submit" class="searchbut"><i class="material-icons">search</i></button>
	
  </form>


		</div>
		<!--/.nav-collapse -->
	</div>
</div>