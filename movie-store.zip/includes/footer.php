<script src="<?php echo $site_url;?>/material/js/bootstrap.min.js"></script>
<script src="<?php echo $site_url;?>/material/js/ripples.min.js"></script>
<script src="<?php echo $site_url;?>/material/js/material.min.js"></script>
<script>
$.material.init();
</script>
<script src="<?php echo $site_url;?>/material/js/jquery.dropdown.js"></script>
<script>
  $(".navbar-form select").dropdown();
  $(".genre-filter select").dropdown();
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
<footer>
<div class="footcontent">
<div class="pull-left">
Copyright &copy; <?php echo date("Y"); ?> <span><?php echo $site_title;?></span>.
</div>
<div class="pull-right">
<a href="<?php echo $site_url;?>"><?php echo $footnav_home; ?></a><span class="footsep"></span><a href="<?php echo $site_url;?>/privacy"><?php echo $footnav_privacy; ?></a><span class="footsep"></span><a href="<?php echo $site_url;?>/dmca"><?php echo $footnav_dmca; ?></a><span class="footsep"></span><a href="<?php echo $site_url;?>/contact"><?php echo $footnav_contact; ?></a>
</div>
<?php if(isset($amazon_id) and !empty($amazon_id)): ?>
<div class="pull-left">
<p style="font-size: 10px;margin:20px  0px  0px  0px;"><?php echo $site_title; ?> is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com.</p>
</div>
<?php endif; ?>
<?php if(isset($apikey) and !empty($apikey)): ?>
<div class="pull-left">
<p style="font-size: 10px;margin:5px  0px  5px  0px;">This product uses the TMDb API but is not endorsed or certified by TMDb.</p>
<img src="<?php echo $site_url;?>/images/tmdblogo.png" height="26">
</div>
<?php endif; ?>
</div>
</footer>
