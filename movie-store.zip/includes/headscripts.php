<?php
//error_reporting(E_All);
ini_set('display_errors', 1);
 error_reporting(0);
// ini_set('display_errors', 0);
?>
<link href="<?php echo $site_url;?>/material/css/bootstrap.min.css" rel="stylesheet">	  
<link href="<?php echo $site_url;?>/material/css/bootstrap-material-design.css" rel="stylesheet">
<link href="<?php echo $site_url;?>/material/css/ripples.css" rel="stylesheet">
<link href="<?php echo $site_url;?>/material/css/jquery.dropdown.css" rel="stylesheet">
<link href="<?php echo $site_url;?>/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo $site_url;?>/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500" type="text/css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>