<?php 
require_once('siteconfig.php');
require_once('url_slug.php');

$page_title = $toprental_title;
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<title><?php echo $page_title; ?> - <?php echo $site_title; ?></title>
		<meta name="description" content="<?php echo $page_title; ?> - <?php echo $site_title; ?>" />
		<meta name="keywords" content="<?php echo $site_keywords; ?>" />
		<meta property="og:site_name" content="<?php echo $site_title; ?>"/>
		<meta property="og:type" content="website"/>
		<meta property="og:title" content="<?php echo $page_title; ?> - <?php echo $site_title; ?>"/>
		<meta property="og:description" content="<?php echo $page_title; ?> - <?php echo $site_title; ?>"/>
		<!-- CSS and Scripts -->
		<?php include 'includes/headscripts.php'; ?>
		<?php include 'ads/head_code.php'; ?>
	</head>
<body>
<?php include 'includes/header.php'; ?> 

<?php 
$catad = file_get_contents("ads/category_top_ad_728x90.php",NULL);
if(isset($catad) and !empty($catad)): ?>
<div class="pagetopbox">
<center>
<?php echo $catad; ?>
</center>
</div>
<?php endif; ?>

<div class="container">
<div class="pagetitle">
<h1><?php echo $page_title; ?></h1>
</div>
<div class="pageresults">
<input type="radio" name="viewswitch" class="viewswitch-small" checked="checked" />
<span class="control first"><i class="material-icons">apps</i></span>

<input type="radio" name="viewswitch" class="viewswitch-medium" />
<span class="control"><i class="material-icons">view_module</i></span>		
			
<input type="radio" name="viewswitch" class="viewswitch-large" />
<span class="control last"><i class="material-icons">menu</i></span>

<div class="genre-filter">
<li class="dropdown">
		<a href="#" data-target="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $filter_title;?> <b class="caret"></b></a>
		<ul class="dropdown-menu">
			<div class="drop-row">
			<li><a href="<?php echo $site_url;?>/top-movie-rentals"><?php echo $gtitle_all;?></a></li>		
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4401/<?php echo canogenre($gtitle_1);?>"><?php echo $gtitle_1;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4402/<?php echo canogenre($gtitle_2);?>"><?php echo $gtitle_2;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4403/<?php echo canogenre($gtitle_3);?>"><?php echo $gtitle_3;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4404/<?php echo canogenre($gtitle_4);?>"><?php echo $gtitle_4;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4405/<?php echo canogenre($gtitle_5);?>"><?php echo $gtitle_5;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4406/<?php echo canogenre($gtitle_6);?>"><?php echo $gtitle_6;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4407/<?php echo canogenre($gtitle_7);?>"><?php echo $gtitle_7;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4408/<?php echo canogenre($gtitle_8);?>"><?php echo $gtitle_8;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4409/<?php echo canogenre($gtitle_9);?>"><?php echo $gtitle_9;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4410/<?php echo canogenre($gtitle_10);?>"><?php echo $gtitle_10;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4411/<?php echo canogenre($gtitle_11);?>"><?php echo $gtitle_11;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4412/<?php echo canogenre($gtitle_12);?>"><?php echo $gtitle_12;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4413/<?php echo canogenre($gtitle_13);?>"><?php echo $gtitle_13;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4414/<?php echo canogenre($gtitle_14);?>"><?php echo $gtitle_14;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4415/<?php echo canogenre($gtitle_15);?>"><?php echo $gtitle_15;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4416/<?php echo canogenre($gtitle_16);?>"><?php echo $gtitle_16;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4417/<?php echo canogenre($gtitle_17);?>"><?php echo $gtitle_17;?></a></li>
			<li><a href="<?php echo $site_url;?>/top-movie-rentals/4418/<?php echo canogenre($gtitle_18);?>"><?php echo $gtitle_18;?></a></li>
			</div>
		</ul>
</li>
</div>

<ul class="page-itemlist">
<?php
$string = file_get_contents('https://itunes.apple.com/'.$site_country.'/rss/topvideorentals/limit=100/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);
if (empty($xml->entry->id)) {
$string = file_get_contents('https://itunes.apple.com/us/rss/topvideorentals/limit=100/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);
}

// Output
$rssresults = '';

foreach ($xml->entry as $val) {
    // edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	$catid = $val->category->attributes()->scheme;
	$catid = str_replace("/id/","xxx",$catid);
	$catid=explode('/id',$catid);
	$catid=explode('?',$catid[1]);
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "250x250", $sslimage);
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	
    $rssresults .= '<li class="page-item"><div class="pagethumb" data-toggle="tooltip" data-placement="top" title="'.$val->imname.'"><a href="'.$site_url.'/movie/'.$musicid[0].'/'.cano($val->imname).'"><img data-src="'.$bigimage.'" src="'.$site_url.'/images/loading.svg" ></a></div>
		<div class="info"><h3><a href="'.$site_url.'/movie/'.$musicid[0].'/'.cano($val->imname).'">'.$val->imname.'</a></h3>
		<h4>'.$val->imartist.'</h4>
		<a class="genre" href="'.$site_url.'/top-movie-rentals/'.$catid[0].'/'.cano($val->category->attributes()->label).'">'.$val->category->attributes()->label.'</a>
		<span class="summary">'.substr($val->summary, 0, 830).'</span>
		</div>
	</li>';
   
}
echo $rssresults;

?>
</ul>
</div>
</div>
<?php 
$catad = file_get_contents("ads/category_bottom_ad_728x90.php",NULL);
if(isset($catad) and !empty($catad)): ?>
<div class="pagebottombox">
<center>
<?php echo $catad; ?>
</center>
</div>
<?php endif; ?>
<script src="<?php echo $site_url;?>/js/imglazyload.js"></script>
<script>
			//lazy loading
			$('.page-itemlist img').imgLazyLoad({
				// jquery selector or JS object
				container: window,
				// jQuery animations: fadeIn, show, slideDown
				effect: 'fadeIn',
				// animation speed
				speed: 600,
				// animation delay
				delay: 400,
				// callback function
				callback: function(){}
			});
</script>
<script>
$(document).ready(function(){

	// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 200) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});

});
</script>
<p id="back-top"><a href="#top"><i class="material-icons">keyboard_arrow_up</i></a></p>
<?php include 'includes/footer.php'; ?>
</body>
</html>